#!/usr/bin/env python3
import math
import rospy
from geometry_msgs.msg import Twist, PoseStamped
from nav_msgs.msg import Odometry, Path
from differential_robot.msg import Encoder_msg

# Входные данные 
linear_speed = 0
angular_speed = 0

# Время и величина скоростей на моменты начала переходных процессов
beginning_time_r, beginning_time_l = 0, 0
w_r_beg, w_l_beg = 0, 0

w_l_real_pr, w_r_real_pr = 0, 0 # Прошлые значения реальных скоростей
odom_position = [0, 0, 0] # Положение робота
left_enc, right_enc = 0, 0 # Энкодеры
w_r_cmd_pr, w_l_cmd_pr = 0, 0 # Прошлые идельные скорости 
trajectory = [[0, 0]] # Траектория

def callbak_func(sp_msg):
    ''' 
    Входные данные
    '''
    global linear_speed, angular_speed, new_data, first_time
    linear_speed = sp_msg.linear.x
    angular_speed = sp_msg.angular.z

def upd_odom():
    '''
    Вычисления
    '''
    global linear_speed, angular_speed, beginning_time_r, beginning_time_l,\
        w_r_beg, w_l_beg, w_l_real_pr, w_r_real_pr, del_time_r, del_time_l, odom_position,\
        w_r_cmd_pr, w_l_cmd_pr, trajectory

    # Идеальные скорости вращения обоих колес
    w_l_cmd = (2 * linear_speed - 0.287 * angular_speed) / (2 * 0.033)
    w_r_cmd = (2 * linear_speed + 0.287 * angular_speed) / (2 * 0.033)
    
    # Проверка на начало нового переходного процесса
    if w_r_cmd_pr != w_r_cmd:
        beginning_time_r = rospy.Time.now()
        beginning_time_r = round(beginning_time_r.to_nsec() / 1e6)	
        w_r_beg = w_r_real_pr   
    if w_l_cmd_pr != w_l_cmd:
        beginning_time_l = rospy.Time.now()
        beginning_time_l = round(beginning_time_l.to_nsec() / 1e6)	
        w_l_beg = w_l_real_pr
    
    time_now = rospy.Time.now()
    
    # Расчет реальных угловых скоростей колес
    del_time_r = round(time_now.to_nsec() / 1e6) - beginning_time_r
    w_r_real = w_r_beg + (w_r_cmd - w_r_beg) * (1 - math.exp(-del_time_r / 0.9))
    
    del_time_l = round(time_now.to_nsec() / 1e6) - beginning_time_l
    w_l_real = w_l_beg + (w_l_cmd - w_l_beg) * (1 - math.exp(-del_time_l / 0.9))
    
    # Расчет реальных линейной и угловой скоростей робота
    V_real = (0.033 * (w_l_real + w_r_real)) / 2
    w_real = (0.033 * (w_r_real - w_l_real)) / 0.287

    # Вычисление координат и ориентации
    odom_position[0] += V_real * math.cos(odom_position[2] + (w_real / 2.0))
    odom_position[1] += V_real * math.sin(odom_position[2] + (w_real / 2.0))
    odom_position[2] += w_real

    # Создание паблишера
    odom_pub = rospy.Publisher('odom', Odometry, queue_size=10)
    
    # Задание данных для публикации
    odom = Odometry()
    odom.header.stamp = rospy.Time.now()
    odom.header.frame_id = 'odom'
    odom.child_frame_id = 'base_link'
    odom.pose.pose.position.x = odom_position[0]
    odom.pose.pose.position.y = odom_position[1]
    odom.pose.pose.position.z = 0
    odom.twist.twist.linear.x = V_real
    odom.twist.twist.angular.z = w_real
    
    # Публикация данных
    rospy.loginfo(odom.pose.pose.position)
    odom_pub.publish(odom)

    # Определение угловых скоростей колес на прошлом шаге
    w_l_real_pr, w_r_real_pr = w_l_real, w_r_real
    w_r_cmd_pr, w_l_cmd_pr = w_r_cmd, w_l_cmd

    # Траектория
    path_pub = rospy.Publisher('path', Path, queue_size=10)
    path_msg = Path()
    path_msg.header.frame_id = 'path'
    trajectory.append([odom_position[0], odom_position[1]])
    for i in range(len(trajectory)):
        pose_msg = PoseStamped()
        pose_msg.pose.position.x = trajectory[i][0]
        pose_msg.pose.position.y = trajectory[i][1]
        pose_msg.pose.position.z = 0.0
        path_msg.poses.append(pose_msg)
        
    path_pub.publish(path_msg)
    
    


def pub_enc():
    '''
    Энкодеры
    '''
    global linear_speed, angular_speed, left_enc, right_enc

    # Вычисление показаний энкодеров
    left_enc += (w_l_real_pr * 0.1 * 4096) / (2 * math.pi)
    right_enc += (w_r_real_pr * 0.1 * 4096) / (2 * math.pi)

    # Публикация показаний
    encoder_pub = rospy.Publisher('encoder_val', Encoder_msg, queue_size=10)
    enc_msg = Encoder_msg()
    enc_msg.header.stamp = rospy.Time.now()
    enc_msg.left_encoder = int(left_enc)
    enc_msg.right_encoder = int(right_enc)
    rospy.loginfo(enc_msg)
    encoder_pub.publish(enc_msg)


if __name__ ==  '__main__':
    rospy.init_node('differential_robot_node') # Инициализация узла
    r = rospy.Rate(10) # Задание частоты работы цикла
    while not rospy.is_shutdown():
        rospy.Subscriber('cmd_vel', Twist, callbak_func)
        upd_odom()
        pub_enc()
        r.sleep()
        
